# Blink

This repository has an example file to blink the LED on an Arduino board.
